require('dotenv').config(); 
console.log('Loaded KuCoin API key:', process.env.KUCOIN_API_KEY); 
